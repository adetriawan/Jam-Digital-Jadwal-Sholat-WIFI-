  ![ESP8266 Uploader Wrapper](screenshot1.png)
  
  # ESP8266 Uploader Wrapper
  Simple Delphi wrapper for ESP8266 Flash and SPIFFS uploader. Compile in Delphi7 and use this component below :
- https://sourceforge.net/projects/rxlib/
- https://github.com/TurboPack/DOSCommand
- Max Storage VCL (included in vcl folder)
